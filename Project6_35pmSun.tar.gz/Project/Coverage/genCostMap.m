function [ cost_map ] = waveCostMap(map,start_pos,end_pos)
cost_map = zeros(size(map));
end

