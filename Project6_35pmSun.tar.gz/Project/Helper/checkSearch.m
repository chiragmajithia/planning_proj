squirrel1.task_id = 0
squirrel1.move2Pos(food(16).loc-[5,5],100)
squirrel1.task_id = 1
squirrel1.move2Pos(food(20).loc-[5,5],100)
f_id = str2num(squirrel1.temp_input{2})
c_id = ones(size(f_id))*10;
fc_id = [f_id c_id];
squirrel1.pickFood(fc_id,100)