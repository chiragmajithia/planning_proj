addpath('../','../Helper')
global map food_loc;
map = zeros(100,150);
food_loc = dropfood(20);
findfood;