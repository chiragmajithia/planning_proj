function circulateAroundObstacle(nP,Pnt)
    r = Pnt(3);
    topLeft = Pnt(1:2) + [-r r];
    topRight = Pnt(1:2) + [r r];
    bottomRight = Pnt(1:2) + [r -r];
    
    for i = nP(2):topLeft(2)
        plot([nP(1) nP(1)], [nP(2) nP(2)+1]);
    end
    
    if(nP(1) == topLeft(1))
        k = 1;
    else
        k = -1;
    end
    
    for i = 1:2*r
        plot([nP(1) nP(1)+k], [nP(2) nP(2)]);
        nP = nP + [k 0];
    end
    
    for i = 1:2*r
        plot([nP(1) nP(1)], [nP(2) nP(2)-1]);
        nP = nP - [0 1];
    end
    
end