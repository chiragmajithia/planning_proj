function [towards,idx] = nearestObstacleCorner(nP,Updated_obst_loc,Obst_loc)
    min_d = 500;
    idx = 0;
    while(1)
        for i = 1:size(Updated_obst_loc,1)
            d = norm(nP-Updated_obst_loc(i,1:2));
            if(d < min_d)
                min_d = d;
                idx = i;
            end
        end
        
        r = Obst_loc(idx,3);
        flag = 0;
        for j = 0:1
            for k = 0:1
                nextP = Updated_obst_loc(idx,1:2) + [(2*j-1)*r (2*k-1)*r];
                if(~collisionChk(nP,nextP,Obst_loc))
                    flag = 1;
                    break;
                end
            end
            if(flag)
                break;
            end
        end
        if(flag)
            towards = Updated_obst_loc(idx,1:2);
            break;
        else
            Updated_obst_loc(idx,:) = [];
        end
    end

end