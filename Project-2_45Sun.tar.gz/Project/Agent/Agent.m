classdef Agent<handle
   
   properties

   	name = 'Agent'
      pos = struct('x',0.0,'y',0.0);
      path_ = [];
      handle = [];
   end


   methods

    %{ Initilization functions%}
      function [] = setName(obj,name_)
        obj.name = name_;
      end

      function [] = setColor(obj,c)
        obj.handle.FaceColor = c;
      end

      
      function [] = spawn(obj)
   		 if ~isempty(obj.handle)
        	disp('Object exists');
     	 else
          x = randi([1 299]);
          y = randi([1 299]);
     	 	obj.handle = rectangle('Position',[x,y,10,10],'FaceColor','m');
         obj.pos.x = x;
         obj.pos.y = y;
     	 end
      end
      %{ Path genration and moving functions%}
      function [] = move(obj,pos2)
      	position = [pos2 obj.handle.Position(3:4)];
      	obj.handle.Visible = 'off';
      	obj.handle = rectangle('Position',position,'FaceColor',obj.handle.FaceColor);
         obj.pos.x = pos2(1)+5;
         obj.pos.y = pos2(2)+5;
      end 

      function []= moveAlongPath(obj,v)
        if(~isempty(obj.path_) && v~=0)
      	h = obj.plotPath();
      	dist = obj.pathDistance();
      	t = dist/v;
      	[r,c] = size(obj.path_);
      	for i = 1:r
      		obj.move(obj.path_(i,:)-[5 5]);
      		pause(t/r);
      	end
      	set(h,'XData',[],'Ydata',[]);
        else
            sprintf('Path empty or v = 0')
        end
      end

      function dist = pathDistance(obj)
        [r,c] = size(obj.path_);
        dist = 0;
        for i = 1:r-1
          d_pos = obj.path_(i,:)-obj.path_(i+1,:);
          dist = dist + hypot(d_pos(1),d_pos(2));
        end
      end

      function h = plotPath(obj)
      	X = obj.path_(:,1);
      	Y = obj.path_(:,2);
      	h = line(X,Y);
      end
      
      function move2Pos(obj,pos2,v)
        obj.path_ = obj.genPath2(pos2);
        obj.moveAlongPath(v);
      end
      function move2Seg(obj,dest,v)
         start = obj.getCurrSeg();
         obj.path_ = getPath2Seg(start,dest);
         obj.moveAlongPath(v);
      end

      function path = genPath2(obj,pos2)
        pos1 = [(obj.pos.x),(obj.pos.y)];
        seg1_indx = getSeg([obj.pos.x,obj.pos.y]);
        sprintf('%d,%d in seg %d',pos1(1),pos1(2),seg1_indx)
        seg2_indx = getSeg([pos2(1),pos2(2)]);
        if(seg2_indx == 0)
          sprintf('%d,%d is inside obstacle or out of map',pos2(1),pos2(2))
          path = [];
        else
          sprintf('%d,%d in seg %d',pos2(1),pos2(2),seg2_indx)      
          [v,p] = pathLoS(pos1,pos2);
          if(v)
            path = p;
          else
            seg1_center = getSegCenter(seg1_indx);
            [v1,p1] = pathLoS(pos1,seg1_center);
            p2 = getPath2Seg(seg1_indx,seg2_indx);
            [v3,p3] = pathLoS(p2(end,:),pos2);
            path = [p1;p2;p3];
          end
        end

      end
      

      %{%}
      function [pos_w,pos_s] = locateFood(obj,v_r)
      
      end


      function [id] = getCurrSeg(obj)
         id = getSeg([obj.pos.x,obj.pos.y]);
      end


      %Probably useless
      function [] = addVertex(obj,v)
        obj.path_ = [obj.path_; v];
      end
      
      
   	end
end

%{
	TODO:
	moveStep()
%}