function assignFood()
	global food seg
	for i = 1:size(food)
		id = getSeg(food(i).loc)
		if(id~=0)
			seg(id).addFood([food(i).loc,i])
		else
			sprintf('food(%d) in obstacle space',i)
		end
	end
	cnt = 0;
	for i = 1:size(seg)
		cnt = cnt + size(seg(i).f_loc,1);
		sprintf('seg(%d) food alocated::',i)
		sprintf('%d,',seg(i).f_loc)
	end
	sprintf('Total allocated food:: %d',cnt)
end

